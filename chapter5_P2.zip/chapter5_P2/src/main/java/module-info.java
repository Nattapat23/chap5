module se233.chapter5_p2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens se233.chapter5_p2 to javafx.fxml;
    exports se233.chapter5_p2;
}